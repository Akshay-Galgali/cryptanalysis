This package contains 5 items:
1. An encryptor tool that uses the Caesar Cipher to encrypt any file. The user may pick the ASCII shift of the data.
2. A decryptor tool that, again, uses the Caesar Cipher to decrypt any file previously encrypted with the Caesar Cipher. The user must specify what ASCII shift to decrypt the file with.
3. The source code for the encryptor.
4. The source code for the decryptor.
5. This readme. Try using the encryptor/decryptor on this file to try it out!

Terms of Use:
Anyone may use this encryptor/decryptor.

Description:
These tools are not designed to be secure, and should not be used with the intent of protecting documents designed to be secure. If I could decrypt a file online (www.mezonicagenda.com, the file named "intercepted.enc") than a much more experienced and malicious hacker could, without a doubt, decrypt files. DO NOT USE WITH THE INTENT OF KEEPING VERY SENSITIVE DOCUMENTS SECURE! In addition, I am not responsible for any damage that is caused to a file, or if you forget what cipher shift you used. YOU USE THE ENCRYPTION/DECRYPTION SOFTWARE AT YOUR OWN RISK!

Note: The Programs were written in C. NOT C++, Java, Python, JavaScript, C#, Visual Basic, Quick Basic, TI-83 Basic, DarkBasic, HTML, etc. Written in C!

Troubleshooting:
The program will not open a target file if there are spaces (the character " ") in the target file path (eg "C:\Users\Guest\Desktop\Files to encrypt\unencrypted.txt". The error is in the folder named "Files to encrypt". A workable path would be "C:\Users\Guest\Desktop\Files_to_encrypt\unencrypted.txt".). I have not tested this software on a Macintosh or Apple computer, but I have a feeling that it will not run on Mac OS 10x.

Payments and the like:
I do not require payment.

E-mail me at tigericky@gmail.com for additional questions.
Rick Matheny
Software Developer in Training